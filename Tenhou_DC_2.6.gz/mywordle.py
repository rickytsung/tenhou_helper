import discord
from discord.ext import commands
import random
import time
prefix = ""
intents = discord.Intents.all()
intents.members = True
client = commands.Bot(command_prefix=prefix,help_command=None,intents=intents)

@client.event
async def wordle_cal(data, ctx, guess):
  text = discord.Embed(title = "Wordle")
  def check(word, guess):
    cw = [0, 0, 0, 0, 0]
    cg = [0, 0, 0, 0, 0]
    verdict = [0, 0, 0, 0, 0]
    for i in range(0, 5):
      if(word[i] == guess[i]):
        cw[i] = 1
        cg[i] = 1
        verdict[i] = 1
    for i in range(0, 5):
      for j in range(0, 5):
        if(cw[i] != 0 or cg[j] != 0):
          continue
        if(word[i] == guess[j]):
          cw[i] = 1
          cg[j] = 1
          verdict[j] = 2
    return verdict

  def two_step(pre, now, answer):
    vpre = check(answer, pre)
    ap = [0] * 26
    for i in range(0, 5):
      if(vpre[i] == 1):
        if(now[i] != pre[i]):
          return False
      else:
        if(vpre[i] == 2):
          ap[ord(pre[i]) - ord('a')] += 1
        ap[ord(now[i]) - ord('a')] -= 1
  
    for i in ap:
      if(i > 0):return False
    return True

  #print("input" ,data, guess)
  if (data['mode'] == "cyclic"):
    if (len(guess) != 5): 
      text.add_field(name="Error : Your input is not correct. (Cyclic mode)", value = "", inline=False)
      await ctx.channel.send(embed = text)
      return 
    in_word_list = False
    for i in range(5):
      guess = guess[1:] + guess[0]
      print(guess)
      if (guess in data['word_list']): in_word_list = True
    if (in_word_list == False): # 
      text.add_field(name="Error : Your input is not correct. (Cyclic mode)", value = "", inline=False)
      await ctx.channel.send(embed = text)
      return 
  else:
    if (len(guess) != 5 or guess not in data['word_list']): 
      text.add_field(name="Error : Your input is not correct.", value = "", inline=False)
      await ctx.channel.send(embed = text)
      return 

  if(guess in data['guess_word']):
    text.add_field(name="Error : You guessed the same word before!", value = "", inline=False)
    await ctx.channel.send(embed = text)
    return 

  if(data['mode'] == "not"): # not mode
    if(len(data['guess_word']) >= 1):
      last_word = data['guess_word'][-1]
      for i in range(0, 5):
        for j in range(0, 5):
          if(guess[i] == last_word[j]):
            text.add_field(name="Error : In NOT mode, you can't have the same letter in the word as previous one.", value = "", inline=False)
            await ctx.channel.send(embed = text)
            return 
   
  if(data['mode'] == "fixing"): # fixing mode
    if(len(data['guess_word']) >= 1):
      last_word = data['guess_word'][-1]
      same = two_step(last_word, guess, data['answer'])
      if(same == False):
        text.add_field(name="Error : In fixing mode, you need to have same letters as previous green in the exact same position before, and have same letters as previous yellow in random position.", value = "", inline=False)
        await ctx.channel.send(embed = text)
        return 
   ## above code for validating input
  data['sys_time'] = time.time()
  data['guess_count'] += 1
  data['guess_word'].append(guess)
  result = []
  correct = 1
  this_correct = 1
  
  if data["mode"] == "double" or data["mode"] == "triple" or data["mode"] == "quadruple" or data["mode"] == "puppet":
    for i in range(len(data['answer'])):
      if data['answer'][i] != "":
        ret = check(data['answer'][i], guess)
        this_correct = 1
      else:
        ret = [1, 1, 1, 1, 1]
        
      for j in ret:
        if(j != 1):
          correct = 0
          this_correct = 0
          
      if(this_correct == 1):
        data['answer'][i] = ""
      result.append(ret)

  elif (data["mode"] == "flipping"):
    result = [check(guess, data['answer'])]
    for i in result[0]:
      if(i != 1):
        correct = 0
  else:
    result = [check(data['answer'], guess)]
    for i in result[0]:
      if(i != 1):
        correct = 0
        
  if data["mode"] == "mixing":
    for i in range(5):
      result[0][i] = data['shuffle'][result[0][i]]
    
  if data["mode"] == "puppet" and correct == 0:
    if data['answer'][0] != "" and data['answer'][1] != "": 
      rand = random.randint(0, 1)
      print(rand)
      result = [result[rand]]

  if data["mode"] == "lying" and correct == 0:
    rand = random.randint(0, 1)
    if(rand == 1):
      for i in range(5):
        rand2 = random.randint(1, 2)
        result[0][i] = (result[0][i] + rand2) % 3
  # above for result
  #print("before print", data)
  
  restr = data["mode"] + " mode || Guess : " + str(data['guess_count']) + "\n"
  for i in range(0, 5):
    restr += ":regional_indicator_" + guess[i] + ": "  
  restr += "\n"

  all_correct = 0
  for i in result:
    for j in range(5): #j -> a char
      if(i[j] == 0):
        restr += ":black_large_square: " 
      if(i[j] == 1):
        restr += ":green_square: " 
      if(i[j] == 2):
        restr += ":yellow_square: " 
    restr += "\n"

  if(correct == 1):
    restr += "Congrats on <@" + str(ctx.author.id) + "> getting the right answer!\n"
    data['mode'] = "free"
# ctx.author.id #send
  print(correct, guess, data['mode'], data['answer'])
  text.add_field(name="", value = restr, inline=False)
  await ctx.channel.send(embed = text)
  return 