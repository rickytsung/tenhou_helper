import math
import discord
#import urllib.parse
from discord.ext import commands
#from keep_alive import keep_alive
#from replit import db
#from bs4 import BeautifulSoup as bsp
#import os
#import json
#import requests
#import time
#import random
prefix = ""
intents = discord.Intents.all()
intents.members = True
client = commands.Bot(command_prefix=prefix,help_command=None,intents=intents)

class InvalidException(Exception):
    pass
  
@client.event
async def fun(lv,fa,sa,f,s,last):
  sz=int(math.ceil(lv*200/15))*2-1
  if(lv%3==0):
    sz -= 1
  cnt=0
  dp = [0]*300
  uf=0;df=0;
  dp[sz//2]=1;
  u=0;d=0
  while(cnt < 5000 and uf+df < 0.9999):
    cnt += 1
    dp2 = [0]*300
    for j in range(sz):
      u = j + fa
      u2 = j + sa
      d = j - 2 - lv;
      
      if(u >= sz) :
        uf += dp[j]*f;
      else :
        dp2[u] += dp[j]*f;

      if(u2 >= sz) :
        uf += dp[j]*s;
      else :
        dp2[u2] += dp[j]*s;
        
      if(d < 0) :
        df += dp[j]*last;
      else :
        dp2[d] += dp[j]*last;
  
    dp,dp2 = dp2,dp
  prec = 10000
  uf *= prec
  df *= prec
  uf //= 1
  df //= 1

  sumf = uf + df
  if(sumf  < prec):
    df += (prec - sumf + 1) // 2 
    uf += (prec - sumf) // 2 
  uf /= (prec//100)
  df /= (prec//100)
  return [round(uf,2),round(df,2)]

tran = []

for i in range(1,11):
  tran.append(fun(i,7,0,1/2,0,1/2))
print(tran)


'''
dp = [0] * 11
dp2 = [0] * 11,
for i in range(20):
  for j in range(0,9):
    dp2 [j+1] += dp [j] + tran[j][0]*tran[j][2]
  for j in range(1,9):
    dp2 [j-1] += dp [j] + tran[j][1]*tran[j][3]

  dp,dp2 = dp2,dp

print(dp)
'''
level2 = ["〇","初","二","三","四","五","六","七","八","九","十","天"]

@client.event
async def go(name,foot,ctx,msg):
  f = 0; s = 0 ; last = 0
  fa = 0; sa = 0; mode = -1
  lst = msg[1].strip().split("-")
  for i in range(len(lst)):
    lst[i] = int(lst[i])
  if(len(msg[0]) != 2):
    raise InvalidException
  elif(msg[0][0] == "三"):
    if(msg[0][1] == "上"):
      fa = 5
      mode = 2
    elif(msg[0][1] == "特"):
      fa = 7
      mode = 3
    elif(msg[0][1] == "鳳"):
      fa = 9
      mode = 4
    else:
      raise InvalidException
    f = lst[0]/(lst[0]+lst[2])
    last = 1 - f
  elif(msg[0][0] == "四"):
    if(msg[0][1] == "上"):
      fa = 4
      sa = 1
      mode = 2
    elif(msg[0][1] == "特"):
      fa = 5
      sa = 2
      mode = 3
    elif(msg[0][1] == "鳳"):
      fa = 6
      sa = 3
      mode = 4
    else:
      raise InvalidException
    f = lst[0]/(lst[0]+lst[1]+lst[3])
    s = lst[1]/(lst[0]+lst[1]+lst[3])
    last = 1 - f - s
  else:
    raise InvalidException
  text = discord.Embed(title = name)   
  text.add_field(name=msg[0]+"升降機率", value = "", inline=False)
  text.set_footer(text = foot)
  if(mode == 2):
    for i in range(1,7):
      ret = await fun(i,fa,sa,f,s,last)
      text.add_field(name=level2[i]+"段", value = "升段機率: " + str(ret[0])+" % 降段機率: "+str(ret[1])+" % ", inline=False)
  if(mode == 3):
    for i in range(4,11):
      ret = await fun(i,fa,sa,f,s,last)
      text.add_field(name=level2[i]+"段", value = "升段機率: " + str(ret[0])+" % 降段機率: "+str(ret[1])+" % ", inline=False)
  if(mode == 4):
    for i in range(7,11):
      ret = await fun(i,fa,sa,f,s,last)
      text.add_field(name=level2[i]+"段", value = "升段機率: " + str(ret[0])+" % 降段機率: "+str(ret[1])+" % ", inline=False)
  await ctx.channel.send(embed = text)

  