import math
import discord
from discord.ext import commands
prefix = ""
intents = discord.Intents.all()
intents.members = True
client = commands.Bot(command_prefix=prefix,help_command=None,intents=intents)

# 3 digit 301 -> [3ma][east][moon]
# the penalty calculation function is composed by several linear function
# the function for 3rd in 4p moon table 1d~3d is modifed to linear fucction to avoid -inf dan, so this segment's result is different from original.  
def cal31(table):
  if(table == 301):
    return 50
  if(table == 302):
    return 90
  if(table == 303):
    return 160
  if(table == 311):
    return 75
  if(table == 312):
    return 135
  if(table == 313):
    return 240

def cal33(table, lv):
  if(table == 301):
    if(lv <= 3):
      return - 20 - lv * 5
    if(lv <= 4):
      return 10 - lv * 15
    return -10 - lv * 10
  if(table == 302):
    return - 20 - lv * 10
  if(table == 303):
    return - 80 - lv * 10
  if(table == 311):
    if(lv <= 2):
      return - 25 - lv * 10
    if(lv <= 3):
      return - 35 - lv * 5
    if(lv <= 4):
      return 25 - lv * 25
    return - 15 - lv * 15
  if(table == 312):
    return - 30 - lv * 15
  if(table == 313):
    return - 120 - lv * 15

def cal41(table):
  if(table == 401):
    return 70
  if(table == 402):
    return 130
  if(table == 403):
    return 200
  if(table == 411):
    return 105
  if(table == 412):
    return 195
  if(table == 413):
    return 300

def cal42(table):
  if(table == 401):
    return 35
  if(table == 402):
    return 50
  if(table == 403):
    return 65
  if(table == 411):
    return 55
  if(table == 412):
    return 75
  if(table == 413):
    return 100

def cal43(table, lv):
  if(table == 401):
    if(lv <= 3):
      return - 15 - lv * 5
    if(lv <= 4):
      return - 10 * lv
    return - 20 - lv * 5

  if(table == 402):
    return - 20 - lv * 5

  if(table == 403):
    return - 50 - lv * 5
    
  if(table == 411):
    if(lv <= 3):
      return 22.5 - lv * 7.5
    if(lv <= 4):
      return -lv * 15
    if(lv <= 5):
      return - 20 - lv * 10
    return - 45 - lv * 5

  if(table == 412):
    if(lv <= 5):
      return - 40 - lv * 5
    if(lv <= 7):
      return - 15 - lv * 10 
    if(lv <= 8):
      return - 50 - lv * 5
    if(lv <= 9):
      return - 10 - lv * 10
    return - 55 - lv * 5

  if(table == 413):
    if(lv <= 9):
      return - 95 - lv * 5
    return - 50 - lv * 10
    
def cal44(table, lv):
  if(table == 401):
    if(lv <= 2):
      return -20 - lv * 10
    if(lv <= 3):
      return - lv * 20
    if(lv <= 4):
      return 60 - lv * 40
    return - 80 - lv * 5

  if(table == 402):
    if(lv <= 6):
      return - 80 - lv * 5
    if(lv <= 7):
      return 70 - 30 * lv
    return - 70 - lv * 10

  if(table == 403):
    if(lv <= 8):
      return -150 - lv * 5
    if(lv <= 9):
      return -110 - lv * 10
    else:
      return -20 - lv * 20  

  if(table == 411):
    if(lv <= 2):
      return -30 - lv * 15
    if(lv <= 3):
      return - lv * 30
    if(lv <= 4):
      return 90 - lv * 60
    if(lv <= 5):
      return -110 - lv * 10
    return -135 - lv * 5

  if(table == 412):
    if(lv <= 5):
      return - 130 - lv * 5
    if(lv <= 6):
      return - 105 - lv * 10
    if(lv <= 7):
      return 105 - lv * 45 
    return - 105 - lv * 15

  if(table == 413):
    if(lv <= 8):
      return -245 - lv * 5
    if(lv <= 9):
      return -165 - lv * 15
    else:
      return -30 - lv * 30


@client.event
async def go(name,foot,ctx,msg):
  lst = msg[1].strip().split("-")
  if(len(msg[0]) != 4 or len(msg[1]) > 20):
    raise Exception("Invalid input.")
    
  for i in range(len(lst)):
    lst[i] = int(lst[i])
  num = -1
  leng = -1
  room = -1
  if(msg[0][0] == "三" and len(lst) == 3):
    num = 3
  elif(msg[0][0] == "四" and len(lst) == 4):
    num = 4
  else:
    raise Exception("Invalid input.")
    
  if(msg[0][1:3] == "霞月"):
    room = 1
  elif(msg[0][1:3] == "炎陽"):
    room = 2
  elif(msg[0][1:3] == "銀河"):
    room = 3
  else:
    raise Exception("Invalid input.")

  if(msg[0][3] == "東"):
    leng = 0
  elif(msg[0][3] == "南"):
    leng = 1
  else:
    raise Exception("Invalid input.")

  l = 0
  r = 11
  cnt = 0
  no = 100 * num + 10 * leng + room
  stable_dan = "Unknown"
  while(l < r and cnt <= 60):
    cnt += 1
    m = (l + r) / 2
    delta = 0
    if(num == 3):
      delta = lst[0] * cal31(no) + lst[2] * cal33(no, m) 
    else:
      delta = lst[0]*cal41(no) + lst[1]*cal42(no) + lst[2]*cal43(no, m) + lst[3]*cal44(no, m)
    if(delta > 0):
      l = m
    else:
      r = m 
  stable_dan = str(round(l ,2)) + " 段"  
  if(room == 1):
    if(l <= 1):
      stable_dan = "1- 段"
    if(l >= 6):
      stable_dan = "6+ 段"
  if(room == 2):
   if(l <= 4):
     stable_dan = "4- 段"
   if(l >= 10):
     stable_dan = "10+ 段"
     # if(leng )
     # stable_dan = "天下一番(+"
     # stable_dan += str(round(base * (lst[0] - lst[2])/sum(lst),2))
     # stable_dan += ")"
  if(room == 3):
     if(l <= 7):
       stable_dan = "7- 段"
     if(l >= 10):
       stable_dan = "10+ 段"
  response = "你的" + msg[0] + "戰績之安定段位為: " + stable_dan
  await ctx.send(response)
  return