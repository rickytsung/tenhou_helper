

'''
Tenhou discord bot v.2.4.1 by r1cky.
2024/1/19 13:31
'''

from threading import Thread
import asyncio
import discord
from discord.ext import commands
#from keep_alive import keep_alive
from bs4 import BeautifulSoup as bsp
import os
import ast
import json
import requests
import aiohttp
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import re
import time
import urllib
import ast
import random
#from requests_oauthlib import OAuth1
import tweepy
intents = discord.Intents.all()
intents.members = True

import crawl
import mjs
import calp
import mywordle
import mybattle
import riichicity
import tenhouhack
#import room

#setting:

#####
db = {}
db['TOKEN'] = "MTE5MDEyOTcyMzYxMTgyMDA4Mg.GoSFLU.cPxrftgEvVHOVW2hZQ9nT6hOR9PWEdCBqoSKgs" 
api_key = "CEtiSDpfIH47KmCNLcjhHKimj"
api_secret = "0CkM3viIXteD0i1BtqevCgCnu0pZSJTkRATsNUy8x0pU7cgEw7"
bearer_token = r"AAAAAAAAAAAAAAAAAAAAABJfsAEAAAAAZJDu3c3JIIcNV8ftmVOr26HGUaM%3DCxasYatdy19y4qxm1VDSDGs1jMqCYYpAzZGaIcMCvF3SWyRABt"
access_token = "1635411918080069632-99KKz9CuSdt2uAMqrGX9CaIcJZi3qZ"
access_token_secret = "TLBl8ho78xvx0V8b4LbyBFcTL89c99umm2Nu4NokHzoeL"
#cilent id QVUwaFB0TTdSdFFDaG1xa3B5bm06MTpjaQ
#cilent secret y5jLG80h5FhmxqyPVH2cR7yiKoGB1TupT-813E0Joe5zNDwNKF
#token

start_time = 0
api_broken = 0
rank_list_update = 0 
rankd4 = {} ; rankd3 = {}
player_cond = {}
pre_match = {}
match_set = set()
ch = 1190129131896176730 #annel id
rch = 1190129131896176730
botch = 1190129131896176730
#db['init'] = 1
prefix = '&'

db['mention'] = {} #initialize
db['user'] = [] #initialize
pool = []

f = open('watch_database.txt',  'r')
text = f.read()
pool = ast.literal_eval(text)
f.close()

f = open('wordle_word.txt',  'r')
text = f.read()
word = text.split(" ")
f.close()

f = open('wordle_word2.txt',  'r')
text = f.read()
word_2 = text.split(" ")
f.close()

f = open('watch_pre_match.txt',  'r')
text = f.read()
pre_match = ast.literal_eval(text)

f.close()

f = open('battle.txt',  'r')
text = f.read()
battle_db = ast.literal_eval(text)

f.close()

for i in pool:
   db['user'].append([i[0],["x",0,0,0,0],["x",0,0,0,0],"0"])
   db['mention'][i[0]] = []
   for j in i[1]:
     db['mention'][i[0]].append(j)

wordle_data = {}
wordle_data['mode'] = "free"
wordle_data['guess_count'] = 0
wordle_data['answer'] = "apple"
wordle_data['guess_word'] = []
wordle_data['shuffle'] = [0,1,2]
wordle_data['problem'] = word
wordle_data['word_list'] = word_2
wordle_data['sys_time'] = 0

my_game = ["Gomi Game","天鳳","角田","bot-hosting.net", "PY", "雀魂麻將", "你媽", "ㄌㄌ", "女裝", "薩米", "小姪女", "麻雀一番街", "ㄐㄐ",  "君が僕に見せてくれた", "探しにいくよ 内なる花を", "晴れに晴れ、花よ咲け 咲いて晴るのせい", "失恋ソング沢山聴いて 泣いてばかりの私はもう", "君と僕の終わらない154小節戦争", "僕の中に 誰がいるの？", "揺れて 消えて 歌っているの" ,"輝く言葉が 背中を押した", "Yes, and...", "bling bang bang born", "絶対嘘じゃない 愛してる"]

client = commands.Bot(command_prefix=prefix, help_command=None,intents=intents)
channel = client.get_channel(ch)
name = "Tenhou" #bot name
st = "Gomi Game"
foot ="Tenhou bot v.2.5 by r1cky"
ex = discord.Embed(title = "Exception")
ex.set_footer(text = foot)
dn = discord.Embed(title = "Permission Denied")
dn.set_footer(text = foot)
mp = {}
mp_reload = True
mtn = False
high_dan = [] # [player_num, name, link]

twi_client = tweepy.Client(bearer_token, api_key, api_secret, access_token, access_token_secret)
auth = tweepy.OAuth1UserHandler(api_key, api_secret, access_token, access_token_secret)
api = tweepy.API(auth, wait_on_rate_limit=True)

@client.event
async def on_message(msg):
  try:
    await client.process_commands(msg)
  except:
    return

class AsyncLoopThread(Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.loop = asyncio.new_event_loop()

    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

loop_handler = AsyncLoopThread()
loop_handler.start() #start another thread

@client.command()
async def help(ctx):
  text = discord.Embed(title = name)
  text.add_field(name=prefix+"add [name]", value = "添加名為 [name] 的玩家到觀戰列表。", inline=False)
  text.add_field(name=prefix+"remove [name]", value = "從觀戰列表移除名為 [name] 的玩家。", inline=False)
  #text.add_field(name=prefix+"add_room [id]", value = "開啟個室 [id] 觀戰(玩家要在觀戰列表內)。", inline=False)
  #text.add_field(name=prefix+"remove_room [id]", value = "關閉個室 [id] 觀戰。", inline=False)
  text.add_field(name=prefix+"mention_on [name]", value = "從觀戰列表中選取一個人 [name] 開啟個人提醒功能。", inline=False)
  text.add_field(name=prefix+"mention_off [name]", value = "關閉 [name] 的提醒功能。", inline=False)
  text.add_field(name=prefix+"get_user [name]", value = "查詢 [name] 的天鳳水表。", inline=False)
  text.add_field(name=prefix+"get_user_mjs [name]", value = "查詢 [name] 的雀魂戰績。 (註 :mjs = 預設，可將其代換成 china = 中文、japan = 日文、inter = 英文", inline=False)
  text.add_field(name=prefix+"list", value = "顯示觀戰列表。", inline=False)
  #text.add_field(name=prefix+"list_room", value = "顯示觀戰個室列表。", inline=False)
  text.add_field(name=prefix+"possibility [場次] [順位]", value = "計算升降段機率。 格式如: possibility 三上 100-100-100", inline=False)
  text.add_field(name=prefix+"wordle_start [mode]", value = "啟動一個新的 wordle，模式為 [mode]，[關於 mode 說明](https://hackmd.io/@r1cky/BkRti3A_T)。", inline=False)
  text.add_field(name=prefix+"wordle_guess [vocab]", value = "wordle 猜一個字。", inline=False)
  text.add_field(name=prefix+"help", value = "顯示本訊息。", inline=False)
  text.set_footer(text = foot)
  await ctx.channel.send(embed = text)

@client.command()
async def wordle_guess(ctx, msg):
  global wordle_data
  text = discord.Embed(title = name) 
  if(wordle_data['mode'] == "free"):
    text.add_field(name="Error : The game hasn't started yet. Use wordle_start command to start.", value = "", inline=False)
    await ctx.channel.send(embed = text)
    return 
  await mywordle.wordle_cal(wordle_data, ctx, msg.strip())
    
@client.command()
async def wordle_start(ctx, msg):
  global wordle_data, foot
  mode = msg.strip()
  text = discord.Embed(title = "Wordle")
  text.set_footer(text = foot)
  if(wordle_data['mode'] != "free" and time.time() - wordle_data['sys_time'] < 300):
    text.add_field(name="Error : The game hasn't ended yet.", value = "You can kill it and start another game if there's no guess for over 5 minutes.", inline=False)
    await ctx.channel.send(embed = text)
    return 

  if(mode == "normal"): wordle_data['answer'] = random.choice(wordle_data['problem'])
  elif(mode == "lying"): wordle_data['answer'] = random.choice(wordle_data['problem'])
  elif(mode == "mixing"):
    wordle_data['answer'] = random.choice(wordle_data['problem'])
    random.shuffle(wordle_data['shuffle']) 
  elif(mode == "fixing"): wordle_data['answer'] = random.choice(wordle_data['problem'])
  elif(mode == "not"): wordle_data['answer'] = random.choice(wordle_data['problem'])
  elif(mode == "flipping"): wordle_data['answer'] = random.choice(wordle_data['problem'])  
  elif(mode == "double"): wordle_data['answer'] = [random.choice(wordle_data['problem']),random.choice(wordle_data['problem'])]
  elif(mode == "triple"):
    wordle_data['answer'] = [random.choice(wordle_data['problem']),random.choice(wordle_data['problem']),random.choice(wordle_data['problem'])]
  elif(mode == "quadruple"):
    wordle_data['answer'] = [random.choice(wordle_data['problem']),random.choice(wordle_data['problem']),random.choice(wordle_data['problem']),random.choice(wordle_data['problem'])]
  elif(mode == "puppet"):
    wordle_data['answer'] = [random.choice(wordle_data['problem']),random.choice(wordle_data['problem'])]
  elif(mode == "cyclic"):
    ori = random.choice(wordle_data['problem'])
    rand = random.randint(0,4)
    for _ in range(rand): ori = ori[1:] + ori[0]
    wordle_data['answer'] = ori
  else:
    text.add_field(name="Error : Wrong game mode parameter. Use wordle_mode command to see details.", value = "", inline=False)
    await ctx.channel.send(embed = text)
    return 

  wordle_data['mode'] = mode
  wordle_data['guess_count'] = 0
  wordle_data['guess_word'] = []

  text.add_field(name="A game has started. || Mode : " + wordle_data['mode'], value = "", inline=False)
  await ctx.channel.send(embed = text)
  return 

@client.command()
async def get_user_battle(ctx, msg):
   global battle_db 
   try:
      await ctx.channel.send(embed = await mybattle.get_user(db, msg))
   except Exception as e:
      await ctx.channel.send("Error: " + str(e)[:30])

@client.command()
async def battle_add(ctx, msg):
   global battle_db 
   try:
      await mybattle.get_user(db, msg)
      await ctx.channel.send("這個牌譜已加入記錄。")
   except Exception as e:
      await ctx.channel.send("Error: " + str(e)[:30])
@client.command()       
async def get_user_mjs(ctx,*msg):
   await get_data(ctx, await get_name(msg),"all")

@client.command()
async def get_user_china(ctx,*msg):
   await get_data(ctx, await get_name(msg),"china")

@client.command()
async def get_user_japan(ctx,*msg):
   await get_data(ctx, await get_name(msg),"japan")

@client.command()
async def get_user_inter(ctx,*msg):
   await get_data(ctx, await get_name(msg),"inter")

@client.event
async def get_name(msg):
  name = ""
  for i in msg:
    name += i + "　"
  return name.strip()

@client.event
async def get_data(ctx,name,server):
  global ex, busy, botname, foot, loop_handler
  await mjs.go(ctx,name,server,"Majsoul",foot,ex,loop_handler)

# @client.command()
# async def add_room(ctx,msg):
#   global ex
#   try:
#     m = int(str(msg))
#     if (m > 9999 or m <= 1000):
#       await ctx.channel.send(embed = ex)
#       return
#     for i in db['room_list']:
#       if m == i:
#        await ctx.channel.send(embed = ex)
#        return
#     db['room_list'] .append(m)
#     text = discord.Embed(title = name)
#     text.add_field(name="個室觀戰 on", value = "Room ID: "+str(m), inline=False)
#     text.set_footer(text = foot)
#     await ctx.channel.send(embed = text)
#   except:
#     await ctx.channel.send(embed = ex)
#     return


@client.command()
async def mention_on(ctx,msg):
  global ex, mp_reload
  m = str(msg)
  id = int(ctx.author.id)
  if(db['mention'].get(m) == None or id in db['mention'][m]):
    await ctx.channel.send(embed = ex)
    return
  db['mention'][m].append(id)
  print(db['mention'][m])
  mp_reload = True
  text = discord.Embed(title = name)
  text.add_field(name="開啟觀戰提醒", value = str(m), inline=False)
  text.set_footer(text = foot)
  await ctx.channel.send(embed = text)

@client.command()
async def mention_off(ctx,msg):
  global ex, mp_reload
  m = str(msg)
  id = int(ctx.author.id)
  if(db['mention'].get(m) == None or id not in db['mention'][m]):
    await ctx.channel.send(embed = ex)
    return
  mp_reload = True
  print(db['mention'][m])
  db['mention'][m].remove(id)
  text = discord.Embed(title = name)
  text.add_field(name="關閉觀戰提醒", value = str(m), inline=False)
  text.set_footer(text = foot)
  await ctx.channel.send(embed = text)

@client.command()
async def list(ctx):
  text = "```"
  for i in db['user']:
    text += i[0] + " "
  text += "```"
  await ctx.channel.send(text)

# @client.command()
# async def list_room(ctx):
#   text = "```"
#   for i in db['room_list']:
#     text += str(i) + " "
#   text += "```"
#   await ctx.channel.send(text)

@client.command()
async def get_user(ctx,msg):
  try:
   await ctx.channel.send(embed = await crawl.go(str(msg),name))
  except: 
    await ctx.channel.send(embed = ex)

@client.command()
async def add(ctx,msg):
  global ex, mp_reload
  m = str(msg)
  r = requests.get(url="https://nodocchi.moe/api/listuser.php?name="+urllib.parse.quote(m), timeout=4)
  if(r.text == "false"):
    await ctx.channel.send(embed = ex)
    return
  for i in db['user']:
    if m == i[0]:
       await ctx.channel.send(embed = ex)
       return
  db['user'].append([m,["x",0,0,0,0],["x",0,0,0,0],"0"])
  db['mention'][m] = []
  mp_reload = True
  text = discord.Embed(title = name)
  text.add_field(name=" ", value = "用戶 " + m + " 已添加至觀戰列表。", inline=False)
  text.set_footer(text = foot)
  await ctx.channel.send(embed = text)


@client.command()
async def remove(ctx,msg):
  global ex, mp_reload
  m = str(msg)
  x = -1
  cnt = 0
  for i in db['user']:
    if m == i[0]:
       x = cnt
    cnt += 1
  if(x != -1):
    db['user'].pop(x)
    mp_reload = True
    text = discord.Embed(title = name)
    text.add_field(name=" ", value = "用戶 " + m + " 已從觀戰名單中移除。", inline=False)
    text.set_footer(text = foot)
    await ctx.channel.send(embed = text)
  else:
    await ctx.channel.send(embed = ex)

@client.event
async def update():
  global ch, start_time, match_set, mp, mp_reload, high_dan, twi_client, pre_match, api_broken, rankd4, rankd3, rank_list_update, my_game
  dan = ["0","初段","二段","三段","四段","五段","六段","七段","八段","九段","十段","天鳳位"]
  dan8 = []
  new_start_time = 0
  api_broken -= 1
  #print("api", api_broken)
  try:
    x = None
    timeout = aiohttp.ClientTimeout(total=3000)
    async with aiohttp.ClientSession(timeout = timeout) as session:
      async with session.get('https://nodocchi.moe/s/wg.js', timeout = 10) as r:
        if r.status == 200: 
          x = await r.json() 
          #print(x)
        else:
          print("wgx")
          raise Exception("not 200")

    if(mp_reload):
      mp = {}
      for i in range(len(db['user'])):
        mp[str(db['user'][i][0])] = int(i)
      L = []
      for ii in db['user']:
        i = ii[0]
        L.append([i, db['mention'][i]])
      mp_reload = False
      f = open("watch_database.txt", "w")
      f.write(str(L))
      f.close()
      #print("rewr")

    # await room.go(mp)

    #print("done")
    for i in x:
      lv = int(i['info']['playerlevel'])
      if(i['info'].get('ron2') != None): 
        continue
      #print(i)
      if(lv != 2 and lv != 3):
        continue
      if(start_time >= int(i['info']['starttime'])): 
        continue
      match_start_time = int(i['info']['starttime'])
      shash = i['info'].get('id') + str(i['info']['starttime'])
      #print(shash)
        
      if(shash in match_set):continue
      match_set.add(shash)
      new_start_time = max(int(i['info']['starttime']), new_start_time)
      leng = i['info'].get('playlength')
      id = i['info'].get('id')
      num = i['info'].get('playernum')
      kuitan = i['info'].get('kuitanari')
      aka = i['info'].get('akaari')
      speed = i['info'].get('rapid')
      pllv = 0
      nc = ""
      wcnt = -1  
      for j in i['players']:
        #print(j)
        lv = int(i['info']['playerlevel'])
        wcnt += 1
        rate = j.get('rate')
        if(rate is None or rate < 1800):
          rate = 1500
        dan2 = j.get('grade')
        if dan2 is None: dan2 = 0
        dan2 = int(dan2)    
        dan2 -= 9
        pllv += dan2
        if(dan2 >= 7):
          nc += dan[dan2] + " " + j['name'] + "\n"

          #k = db['user'][mp[str(j['name'])]]
          #if(k[1] == id): continue
          #k[2] = id
        s = "正在 "
        if(num == 3): s += "三"
        if(num == 4): s += "四"

        if(lv == 2): s += "特"
        if(lv == 3): s += "鳳"

        if(leng == 1): 
          s += "東"
          lv += 10
        if(leng == 2): s += "南"

        if(kuitan == 1): s += "喰"

        if(aka == 1): s += "赤"

        if(speed == 1): s += "速"
        if(speed == 2): s += "光"
        s += " 對戰\n"
        s += "ID: " + id

        if dan2 >= 8: 
            plname = j['name'].replace("&amp;","&")
            pre_num = num
            pre_lv = lv 
            pre_time = 0#init
            #print("pm", pre_match)
            if(pre_match.get(plname) != None): 
                pre_num = pre_match[plname][0]
                pre_lv = pre_match[plname][1]
                pre_time = pre_match[plname][2]
            #name, pre_time, pre_num, pre_rlv, pnum, rlv, rate, id, wcnt
            dan8.append([plname ,pre_time, pre_num ,pre_lv ,num, lv, rate, id, wcnt])
            pre_match[plname] = [num, lv, match_start_time]

        if(mp.get(str(j['name'])) != None):
          db['user'][mp[str(j['name'])]][2] = [id, num, lv, wcnt, rate]
          db['user'][mp[str(j['name'])]][3] = s
          # [name,[oid,opnum,oroom,ow,or],[id,pnum,room,w,r],string]

      if(pllv >= 8 * num): # and time.time() - start_time <= 300
        newh = True
        nc += "\nID: " + id
        for hix in high_dan:
          if(hix[2] == id):
            newh = False
            break
        if(newh and mtn == False):
          high_dan.append([num, nc, id])
          cl = discord.Color.red()
          text = discord.Embed(title = name, color = cl)
          text.add_field(name = "高段對局" , value = nc.replace('_','\_').replace("&amp;","&"), inline=False)   
          cha = client.get_channel(ch)
          wg = "(http://tenhou.net/0/?wg="+str(id)+"&tw=0)"
          links = "\n[觀戰]" + wg 
          text.add_field(name="Links", value = links, inline=False)
          text.set_footer(text = foot)
          if(num == 3):
            await cha.send("<@&1162221115196837918>")
          if(num == 4):
            await cha.send("<@&1162221209430261781>")
          await cha.send(embed = text)

  except Exception as e:
    print(e, "update failed")
    pass
  d = db['user']
  #start_time = max(new_start_time,start_time) - 30
  queried = {}
  for i in d:
    if(i[1][0] != i[2][0]):
      print(i)
      cond = None
      try:
        if(len(i[2]) == 5  and api_broken <= 0):
          pre_time = 0
          plname = i[0].replace("&amp;","&")
    #name, pre_time pre_num, pre_rlv, pnum, rlv, new_R = 0
          if(pre_match.get(plname) != None): 
            pre_time = pre_match[plname][2]
          cond = await crawl.fast_go(i[0], pre_time, i[1][1], i[1][2], i[2][1], i[2][2], i[2][4])
          if(cond is None): cond = ["None", "None"]
          queried[i[0]] = cond
          await asyncio.sleep(5)
      except Exception as e:
        print("condf", e)
        #api_broken = 10 
        cond = None
      i[1] = i[2]
      text = discord.Embed(title = name)
      mens = " "
      for j in db['mention'][i[0]]:
        mens += "<@" + str(j) + "> "
      cond2 = ""
      if(cond is not None and cond[0] != "None"):
        cond2 = "\n(" + cond[0] + ")"
      text.add_field(name=i[0].replace('_','\_'), value = i[3] + cond2, inline=False)
      cha = client.get_channel(ch)
      if(mens != " "):await cha.send(mens)
      wg = "(http://tenhou.net/0/?wg="+str(i[2][0])+"&tw="+str(i[2][3])+")"
      wd = "(https://nodocchi.moe/tenhoulog/#!&name="+str(i[0])+")"
      links = "\n[觀戰]" + wg +" [水表]" + wd
      text.add_field(name="Links", value = links, inline=False)
      text.set_footer(text = foot)
      await cha.send(embed = text)

  rank_list_update -= 1 
  if(len(dan8) == 0 or api_broken > 0): return
  if(rank_list_update <= 0):  
    print("updating rank list", dan8)
    try:
      timeout = aiohttp.ClientTimeout(total=3000)
      async with aiohttp.ClientSession(timeout = timeout) as session:
        async with session.get('https://nodocchi.moe/api/graderank.php?playernum=4&orderby=0&rg=0'+ str(name), timeout = 10) as r:
          if r.status == 200: 
            rank_data = await r.json()  
            rankd4 = {}
            for i in rank_data:
              rankd4[i['username']] = [int(i['grade']), int(i['pt'])]
            await asyncio.sleep(5)##
          else:
            raise Exception("not 200")

        async with session.get('https://nodocchi.moe/api/graderank.php?playernum=3&orderby=0&rg=0'+ str(name), timeout = 10) as r:
          if r.status == 200: 
            rank_data = await r.json()  
            rankd3 = {}
            for i in rank_data:
              rankd3[i['username']] = [int(i['grade']), int(i['pt'])]
            await asyncio.sleep(5)##
          else:
            raise Exception("not 200")
      rank_list_update = 15
      game = discord.Game(random.choice(my_game))
      await client.change_presence(activity=game)
    except Exception as e:
      print("failed fetch rank list", e)
      #api_broken = 10 
      return
  #print(rankd3,rankd4)
  f = open("watch_pre_match.txt", "w")
  f.write(str(pre_match))
  f.close()
  for i in dan8:
    try:
      #print("now", i )  
      mss = None    
      if(queried.get(i[0]) is not None):
        mss = queried.get(i[0]) 
      else:     
        it = None
        if(i[4] == 3):
          it = rankd3.get(i[0])
        if(i[4] == 4):
          it = rankd4.get(i[0])
        if(it is not None):
          print("it", it, i)
          if(it[0] == 17 and it[1] < 2600): continue
          if(it[0] == 18 and it[1] < 2900): continue
          if(it[0] == 19 and it[1] < 3200): continue
          if(it[0] == 20): continue
        else: 
          pass
                  #name, pre_time, pre_num, pre_rlv, pnum, rlv, rate, id, wcnt
        mss = await crawl.fast_go(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
        await asyncio.sleep(10)
      if(mss is not None and mss[1] != "" and mss[1] != "None"):
        #continue
        tw = str(mss[1]) + "\nLink: http://tenhou.net/0/?wg=" + i[7] + "&tw=" + str(i[8]) +"\nTenhouWatch by rickytsung"
        my_tweet = twi_client.create_tweet(text = str(tw))
        tw_url = f"https://fxtwitter.com/TenhouWatch/status/{my_tweet[0]['id']}"
        print(tw_url)
        cha = client.get_channel(1197412775333462097)
        await cha.send(tw_url)

    except Exception as e:
          print("Couldn't fetch cond data", e)

@client.command()
async def possibility(ctx,*msg):
   try:
     await calp.go(name,foot,ctx,msg)
   except:
     await ctx.channel.send(embed = ex)

@client.command()
async def rc_stable(ctx,*msg):
   try:
     await riichicity.go(name,foot,ctx,msg)
   except Exception as e:
     await ctx.channel.send("Error: " + str(e)[:50])
       
@client.command()
async def get_data(ctx,*msg):
   try:
     await tenhouhack.go(ctx,msg)
   except Exception as e:
     await ctx.channel.send("Error: " + str(e)[:50])
        
@client.event
async def on_ready():
    global st,cha, start_time
    game = discord.Game("啟動中...")
    print("ready")
    start_time = time.time() - 120
    await client.change_presence(status=discord.Status.online, activity=game)
    await update()
    scheduler = AsyncIOScheduler(timezone="Asia/Taipei")
    scheduler.add_job(update, 'interval', minutes = 2)
    scheduler.start()

client.run(db['TOKEN'])
