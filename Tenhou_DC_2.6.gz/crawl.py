import discord
import urllib.parse
from discord.ext import commands
from bs4 import BeautifulSoup as bsp
import os
import json
import requests
import time
import random
import aiohttp
prefix = ""
intents = discord.Intents.all()
intents.members = True
client = commands.Bot(command_prefix=prefix,help_command=None,intents=intents)


@client.event
async def go(name, botname):
  r = requests.get(url="https://nodocchi.moe/api/listuser.php?name="+urllib.parse.quote(name), timeout=10)
  print(name, r, r.status_code) 
  level = ["0","新人","9級","8級","7級","6級","5級","4級","3級","2級","1級","初段","二段","三段","四段","五段","六段","七段","八段","九段","十段","天鳳位"]
  level2 = ["〇","初","二","三","四","五","六","七","八","九","十","天"]
  def penalty(lv):
    return max(0,(lv-8)*10)

  def upgrade(lv, time):
    pre = 1508792400
    if(time >= pre):
      if(lv <= 4): return 20  
      if(lv <= 5): return 40
      if(lv <= 6): return 60
      if(lv <= 7): return 80
      if(lv <= 10): return 100
      return 400*(lv-10)
    else:
      if(lv <= 3): return 30
      if(lv <= 6): return 60
      if(lv <= 7): return 90
      if(lv <= 10): return 100
      return 400*(lv-10)

  def startpt(lv):
    if(lv <= 10): return 0
    return 200*(lv-10)

  def cal3(t,a,b,c,lv):
    return (t * 20 + 30) * a - c * penalty(lv)

  def cal4(t,a,b,c,d,lv):
    if t == 0:
      return (20 * a + 10 * b - d * penalty(lv))
    return (t * 10 + 30) * a + t * 10* b - d * penalty(lv)

  def stable_R(num, table, rank):
    #print(num, table, rank)
    tot = 0
    for i in rank:
      tot += i
    if(num == 3):
      TR3 = [1500, 1660, 1933, 2161]
      change = [30, 0, -30]
      l = 0
      r = 3000
      m = 0
      for _ in range(60):
        d = 0
        m = (l+r) /2 
        for i in range(3):
          d += change[i] * rank[i] / tot
        d += (TR3[table] - m)/40
        #print(d)
        if(d < 0):
          r = m
        else:
          l = m

    if(num == 4):
      TR4 = [1500, 1621, 1892, 2113]
      change = [30, 10, -10, -30]
      l = 0
      r = 3000
      m = 0
      d = 0
      for _ in range(60):
        d = 0 
        m = (l+r) /2 
        for i in range(4):
          d += change[i] * rank[i] / tot
        d += (TR4[table] - m)/40
        if(d < 0):
          r = m
        else:
          l = m
    if(m <= 0.5):
      return "0-"
    if(m >= 2999.5):
      return "3000+"
    m //= 1
    m = int(m)
    return m
  pt3 = 0
  lv3 = 1
  pt4 = 0
  lv4 = 1

  st3 = []
  st4 = []
  re3 = []
  re4 = []

  new3 = " \n"
  new4 = " \n"
  last_time = 0
  updatelv = False

  data = json.loads(r.text)
  r3 = r4 = 1500
  try:
    r3 = data.get('rate').get('3')
    r4 = data.get('rate').get('4')
    if(r3 == None): r3 = 1500
    if(r4 == None): r4 = 1500
  except:
    pass

  for i in data['list']:
    if(int(i['starttime']) - last_time > 60*60*24*180 and lv3 <17 and lv4 < 17):
      new3 = " \n"
      new4 = " \n"
      pt3 = 0;lv3 = 1;pt4 = 0;lv4 = 1;re3 = []; re4 = []
      for k in range(4):
        re4.append([[0,0,0,0],[0,0,0,0]])
        re3.append([[0,0,0],[0,0,0]])

    last_time = int(i['starttime'])

    if(i['playernum'] == '3'):
      if(i.get('lobby') != None or (i.get('sctype') != 'c' and i.get('sctype') != 'b')):continue
      if(pt3 >= upgrade(lv3, int(i['starttime']))): #
        lv3 += 1 #
        pt3 = startpt(lv3) #
      lst = []
      for j in range(1,4):
        lst.append([i['player'+str(j)],float(i['player'+str(j)+'ptr'])])
      lst.sort(key=lambda x:x[1],reverse=True)
      if(lst[0][0] == name):
        pt3 += (int(i['playerlevel'])* 20 + 30)*(1 + int(i['playlength']))//2
        re3[int(i['playerlevel'])][int(i['playlength'])-1][0] += 1
      if(lst[1][0] == name):
        re3[int(i['playerlevel'])][int(i['playlength'])-1][1] += 1
      if(lst[2][0] == name):
        pt3 -= penalty(lv3)*(1 + int(i['playlength']))//2
        re3[int(i['playerlevel'])][int(i['playlength'])-1][2] += 1

      if(pt3 < 0):
        if(lv3 == 21):
          continue
        elif(lv3 <= 10):
          pt3 = 0
        else:
          lv3 -= 1
          pt3 = startpt(lv3)
          updatelv = True
      if(pt3 >= upgrade(lv3,int(i['starttime']))):
        if(lv3 == 21):
          continue
        lv3 += 1
        pt3 = startpt(lv3)
        if(lv3 > 9):
          updatelv = True
      if(updatelv) : 
        new3 = level2[lv3-10] + new3
      updatelv = False

    if(i['playernum'] == '4'):
      if(i.get('lobby') != None or (i.get('sctype') != 'c' and i.get('sctype') != 'b')):continue
      if(pt4 >= upgrade(lv4, int(i['starttime']))): #
        lv4 += 1 #
        pt4 = startpt(lv4) #

      lst = []
      for j in range(1,5):
        lst.append([i['player'+str(j)],float(i['player'+str(j)+'ptr'])])
      lst.sort(key=lambda x:x[1],reverse=True)
      if(lst[0][0] == name):
        pt4 += (int(i['playerlevel'])* 10 + 30)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][0] += 1
      if(lst[1][0] == name):
        pt4 += (int(i['playerlevel'])* 10)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][1] += 1
      if(lst[2][0] == name):
        re4[int(i['playerlevel'])][int(i['playlength'])-1][2] += 1
      if(lst[3][0] == name):
        pt4 -= penalty(lv4)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][3] += 1
      if(int(i['playerlevel']) == 0 and int(i['starttime']) >= 1508792400):
        if(lst[0][0] == name): pt4 -= 10 *(1 + int(i['playlength']))//2
        if(lst[1][0] == name): pt4 += 10 *(1 + int(i['playlength']))//2

      if(pt4 < 0):
        if(lv4 == 21):
          continue
        elif(lv4 <= 10):
          pt4 = 0
        else:
          lv4 -= 1
          pt4 = startpt(lv4)
          updatelv = True
      if(pt4 >= upgrade(lv4,int(i['starttime']))):
        if(lv4 == 21):
          continue
        lv4 += 1
        pt4 = startpt(lv4)
        if(lv4 > 9):
          updatelv = True
      if(updatelv) : 
        new4 = level2[lv4-10] + new4
      updatelv = False


  cnt = 0
  for i in re3:
    now = []
    for j in i:
      l = -2
      #l = random.randint(15,30)
      r = 100
      x = 0
      while(l != r and x < 60):
        m = (l+r) / 2
        if(cal3(cnt,j[0],j[1],j[2],m+10) > 0):
          l = m
        else:
          r = m
        x += 1
      if(l>99.99):now.append("inf")
      else:now.append(round(l,2))
    cnt += 1
    st3.append(now)

  cnt = 0
  for i in re4:
    now = []
    for j in i:
      l = -2
      r = 100
      x = 0
      while(l != r and x < 60):
        m = (l+r) / 2
        if(cal4(cnt,j[0],j[1],j[2],j[3],m+10) > 0):
          l = m
        else:
          r = m
        x += 1
      if(l>99.99):now.append("inf")
      else:now.append(round(l,2))
    cnt += 1
    st4.append(now)

  d = [name,[level[lv3],pt3,re3,st3,r3,new3,lv3],[level[lv4],pt4,re4,st4,r4,new4,lv4]]

  def upgrade(lv):
    if(lv <= 4): return 20
    elif(lv <= 5): return 40
    elif(lv <= 6): return 60
    elif(lv <= 7): return 80
    elif(lv <= 10): return 100
    elif(lv == 21): return "inf"
    return 400*(lv-10)

  text = discord.Embed(title = botname)
  table = ["般","上","特","鳳"]

  leng = ["東", "南"] 
  url = "https://nodocchi.moe/tenhoulog/#!&name="+urllib.parse.quote(d[0])
  text.add_field(name=d[0], value = "[水表連結](" + url +")", inline=False)
  s3 = ""
  if(len(d[1][5]) > 2):s3 = "段位推移: " + d[1][5] 
  for i in range(4):
    for j in range(2):
      tot = d[1][2][i][j][0] + d[1][2][i][j][1] + d[1][2][i][j][2] 
      if(tot == 0):continue
      s3 += table[i] + leng[j] +" "
      s3 += str(d[1][2][i][j][0])+"-"+str(d[1][2][i][j][1])+"-"+str(d[1][2][i][j][2])
      if(d[1][3][i][j] == "inf" or d[1][3][i][j] >= 1):
        s3 += " (安 "+str(d[1][3][i][j]) +" 段"
      else:
        s3 += " (安 "+str(round(-d[1][3][i][j]+1,2)) +" 級"

      if (i > 0): 
        s3 += ", R "
        s3 += str(stable_R(3, i, d[1][2][i][j]))

      if(tot < 500): s3 += " ? "

      s3 += ")\n"
  if(s3 == ""): s3 = "無資料"
  grade3 = str(d[1][0]) + " " +str(d[1][1])+"/"+str(upgrade(d[1][6]))+" pt"
  if(d[1][4]==1500):
    text.add_field(name="三麻 "+ grade3 ,value = s3, inline=False)
  else:
    text.add_field(name="三麻 "+ grade3 +"  Rate "+str(d[1][4]) ,value = s3, inline=False)

  # 4 ma 
  s4 = ""
  if(len(d[2][5]) > 2):s4 = "段位推移: " + d[2][5]
  for i in range(4):
    for j in range(2):
      tot = d[2][2][i][j][0]+d[2][2][i][j][1]+d[2][2][i][j][2]+d[2][2][i][j][3]
      if(tot == 0):continue
      s4 += table[i] + leng[j] +" "
      s4 += str(d[2][2][i][j][0])+"-"+str(d[2][2][i][j][1])+"-"+str(d[2][2][i][j][2])+"-"+str(d[2][2][i][j][3])
      if(d[2][3][i][j] == "inf" or d[2][3][i][j] >= 1):
        s4 += " (安 "+str(d[2][3][i][j]) +" 段"
      else:
        s4 += " (安 "+str(round(-d[2][3][i][j]+1,2)) +" 級"
      if (i > 0): 
        s4 += ", R "
        s4 += str(stable_R(4, i, d[2][2][i][j]))
      if(tot < 500): s4 += " ? "
      s4 += ")\n"
  if(s4 == ""): s4 = "無資料"
  grade4 = str(d[2][0]) + " " +str(d[2][1])+"/"+str(upgrade(d[2][6]))+" pt"
  if(d[2][4]==1500):
    text.add_field(name="四麻 "+ grade4 ,value = s4, inline=False)
  else:
    text.add_field(name="四麻 "+ grade4 +"  Rate "+str(d[2][4]) ,value = s4, inline=False)
  return text




@client.event
async def fast_go(name, pre_time, pre_pnum, pre_rlv, pnum, rlv, new_R = 0):
  print("fast go", name, pre_time, pre_pnum, pre_rlv, pnum, rlv, new_R)	
  timeout = aiohttp.ClientTimeout(total=3000)
  if(pnum is None or rlv is None or pnum < 3):
    print("old")
    return None
  data = []
  async with aiohttp.ClientSession(timeout = timeout) as session:
    async with session.get('https://nodocchi.moe/api/listuser.php?name='+ str(name), timeout = 10) as r:
        if r.status == 200: 
            data = await r.json()  
        else:
            print("Err Fetch")
            return 
  #r = requests.get(url="https://nodocchi.moe/api/listuser.php?name="+urllib.parse.quote(name), timeout=8)
  #print(name, r, r.status_code)  
  level = ["0","新人","9級","8級","7級","6級","5級","4級","3級","2級","1級","初段","二段","三段","四段","五段","六段","七段","八段","九段","十段","天鳳位"]
  pt3 = 0
  lv3 = 1
  pt4 = 0
  lv4 = 1

  def penalty(lv):
    return max(0,(lv-8)*10)

  def penalty_r(lv, room):
    if(room == 2 or room == 3): return max(0,(lv-8)*15)
    return max(0,(lv-8)*10)

  def upgrade(lv, time):
    pre = 1508792400
    if(time >= pre):
      if(lv <= 4): return 20  
      if(lv <= 5): return 40
      if(lv <= 6): return 60
      if(lv <= 7): return 80
      if(lv <= 10): return 100
      return 400*(lv-10)
    else:
      if(lv <= 3): return 30
      if(lv <= 6): return 60
      if(lv <= 7): return 90
      if(lv <= 10): return 100
      return 400*(lv-10)

  def startpt(lv):
    if(lv <= 10): return 0
    return 200*(lv-10)

  def reward3(lv):
    if(lv == 2): return 105
    elif(lv == 3): return 135
    elif(lv == 12): return 70
    elif(lv == 13): return 90
    else:
      print("Err on r3")
      print(lv)
      return 105

  def reward41(lv):
    if(lv == 2): return 75
    elif(lv == 3): return 90
    elif(lv == 12): return 50
    elif(lv == 13): return 60
    else:
      print("Err on r41")
      print(lv)
      return 105

  def reward42(lv):
    if(lv == 2): return 30
    elif(lv == 3): return 45
    elif(lv == 12): return 20
    elif(lv == 13): return 30
    else:
      print("Err on r42")
      return 105

  #data = json.loads(r.text)
  r3 = r4 = 1500

  try:
    r3 = data.get('rate').get('3')
    r4 = data.get('rate').get('4')
    if(r3 == None): r3 = 1500
    if(r4 == None): r4 = 1500
  except:
    pass

  re3 = []; re4 = []
  for k in range(4):
    re4.append([[0,0,0,0],[0,0,0,0]])
    re3.append([[0,0,0],[0,0,0]])

  last_time = 0
  for i in data['list']:
    if(int(i['starttime']) - last_time > 60*60*24*180 and lv3 <17 and lv4 < 17):
      new3 = " \n"
      new4 = " \n"
      pt3 = 0;lv3 = 1;pt4 = 0;lv4 = 1;re3 = []; re4 = []
      for k in range(4):
        re4.append([[0,0,0,0],[0,0,0,0]])
        re3.append([[0,0,0],[0,0,0]])

    last_time = int(i['starttime'])

    if(i['playernum'] == '3'):
      if(i.get('lobby') != None or (i.get('sctype') != 'c' and i.get('sctype') != 'b')):continue
      if(pt3 >= upgrade(lv3, int(i['starttime']))): #
        lv3 += 1 #
        pt3 = startpt(lv3) #
      lst = []
      for j in range(1,4):
        lst.append([i['player'+str(j)],float(i['player'+str(j)+'ptr'])])
      lst.sort(key=lambda x:x[1],reverse=True)
      if(lst[0][0] == name):
        pt3 += (int(i['playerlevel'])* 20 + 30)*(1 + int(i['playlength']))//2
        re3[int(i['playerlevel'])][int(i['playlength'])-1][0] += 1
      if(lst[1][0] == name):
        re3[int(i['playerlevel'])][int(i['playlength'])-1][1] += 1
      if(lst[2][0] == name):
        pt3 -= penalty(lv3)*(1 + int(i['playlength']))//2
        re3[int(i['playerlevel'])][int(i['playlength'])-1][2] += 1

      if(pt3 < 0):
        if(lv3 == 21):
          continue
        elif(lv3 <= 10):
          pt3 = 0
        else:
          lv3 -= 1
          pt3 = startpt(lv3)
          updatelv = True
      if(pt3 >= upgrade(lv3,int(i['starttime']))):
        if(lv3 == 21):
          continue
        lv3 += 1
        pt3 = startpt(lv3)
        if(lv3 > 9):
          updatelv = True
      # if(updatelv) : 
      #   new3 = level2[lv3-10] + new3
      updatelv = False

    if(i['playernum'] == '4'):
      if(i.get('lobby') != None or (i.get('sctype') != 'c' and i.get('sctype') != 'b')):continue
      if(pt4 >= upgrade(lv4, int(i['starttime']))): #
        lv4 += 1 #
        pt4 = startpt(lv4) #

      lst = []
      for j in range(1,5):
        lst.append([i['player'+str(j)],float(i['player'+str(j)+'ptr'])])
      lst.sort(key=lambda x:x[1],reverse=True)
      if(lst[0][0] == name):
        pt4 += (int(i['playerlevel'])* 10 + 30)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][0] += 1
      if(lst[1][0] == name):
        pt4 += (int(i['playerlevel'])* 10)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][1] += 1
      if(lst[2][0] == name):
        re4[int(i['playerlevel'])][int(i['playlength'])-1][2] += 1
      if(lst[3][0] == name):
        pt4 -= penalty(lv4)*(1 + int(i['playlength']))//2
        re4[int(i['playerlevel'])][int(i['playlength'])-1][3] += 1
      if(int(i['playerlevel']) == 0 and int(i['starttime']) >= 1508792400):
        if(lst[0][0] == name): pt4 -= 10 *(1 + int(i['playlength']))//2
        if(lst[1][0] == name): pt4 += 10 *(1 + int(i['playlength']))//2

      if(pt4 < 0):
        if(lv4 == 21):
          continue
        elif(lv4 <= 10):
          pt4 = 0
        else:
          lv4 -= 1
          pt4 = startpt(lv4)
          updatelv = True
      if(pt4 >= upgrade(lv4,int(i['starttime']))):
        if(lv4 == 21):
          continue
        lv4 += 1
        pt4 = startpt(lv4)
        if(lv4 > 9):
          updatelv = True
      # if(updatelv) : 
      #   new4 = level2[lv4-10] + new4
      updatelv = False

  print(name,lv3,pt3,lv4,pt4)
  R_delta = 0
  if(pre_pnum != pnum):
    pre_pnum = pnum
    pre_rlv = rlv 
      #TR3 = [1500, 1660, 1933, 2161]
      #TR4 = [1500, 1621, 1892, 2113]
  delta_time = pre_time - last_time 
  #print(delta_time, pre_time, last_time)
  delta_time = 15*60
  if(r3 != 1500 and pre_pnum == 3 and delta_time >= 15 * 60): 
    R_delta = new_R - r3
    if(pre_rlv == 2 or pre_rlv == 12):
      R_delta -= ((1933*2+r3)/3 - r3)/200 
    if(pre_rlv == 3 or pre_rlv == 13):
      R_delta -= ((2161*2+r3)/3 - r3)/200 
    if(R_delta >= 4):
      pt3 += reward3(pre_rlv)
    if(R_delta <= -4):
      pt3 -= penalty_r(lv3, pre_rlv)
    if(pt3 < 0 or pt3 >= upgrade(lv3, 2e9)):
      return None
  elif(r4 != 1500 and pre_pnum == 4 and delta_time >= 15 * 60):  
    R_delta = new_R - r4
    R_delta_unfixed = new_R - r4
    if(pre_rlv == 2 or pre_rlv == 12):
      R_delta -= ((1892*3+r4)/4 - r4)/200 
    if(pre_rlv == 3 or pre_rlv == 13):
      R_delta -= ((2113*3+r4)/4 - r4)/200 
    if(R_delta >= 4):
      pt4 += reward41(pre_rlv)
    elif(R_delta >= 1 and R_delta_unfixed > 0):
      pt4 += reward42(pre_rlv)
    if(R_delta <= -4):
      pt4 -= penalty_r(lv4, pre_rlv)
    if(pt4 < 0 or pt4 >= upgrade(lv4,2e9)):
      return None

  ms = None
  if(pnum == 3):
    if(lv3 == 21): return 
    demote = pt3 // penalty_r(lv3, rlv) + 1
    if(demote <= 5):
      ms = [str(demote) + " 場三位後降至" + level[lv3-1], "None"]
    promote = (upgrade(lv3,2e9) - pt3 - 1) // reward3(rlv) + 1
    if(promote <= 5):
      ms = [str(promote) + " 場一位後升至" + level[lv3+1], "None"]
    if(promote <= 3):
      ms = [str(promote) + " 場一位後升至" + level[lv3+1], name + " さん，三麻" + level[lv3+1] + "M" + str(promote)]
    if(promote == 1):    
      ms = [str(promote) + " 場一位後升至" + level[lv3+1], name + " さん，三麻" + level[lv3+1] + "昇段戰(M1)"]
    if(ms is not None and lv3 <= 17):
      ms[1] = "None"   
  elif(pnum == 4):
    if(lv4 == 21): return
    demote = pt4 // penalty_r(lv4, rlv) + 1
    if(demote <= 5):
      ms = [str(demote) + " 場四位後降至" + level[lv4-1], "None"]
    promote = (upgrade(lv4, 2e9) - pt4 - 1 ) // reward41(rlv) + 1
    if(promote <= 5):
      ms = [str(promote) + " 場一位後升至" + level[lv4+1], "None"] 
    if(promote <= 3):
      ms = [str(promote) + " 場一位後升至" + level[lv4+1], name + " さん，四麻" + level[lv4+1] + "M" + str(promote)] 
    if(promote == 1):    
      ms = [str(promote) + " 場一位後升至" + level[lv4+1], name + " さん，四麻" + level[lv4+1] + "昇段戰(M1)"]
    if((upgrade(lv4, 2e9) - pt4) <= reward42(rlv)):
      ms = ["1 場連對後升至" + level[lv4+1], name + " さん，四麻" + level[lv4+1] + "昇段戰(M1)"]
    if(ms is not None and lv4 <= 17):
      ms[1] = "None"        
  print(name, lv3, pt3, lv4, pt4, ms)
  return ms
