import discord
from discord.ext import commands
import math
import json
import requests
import urllib
import asyncio
import aiohttp
intents = discord.Intents.all()
intents.members = True
prefix = '&'
client = commands.Bot(command_prefix=prefix, help_command=None,intents=intents)
mjsdata = {}

@client.event
async def go(ctx,name,server,botname,foot,ex,lp):
  data0 = []
  global mjsdata
  try:
    r0 = requests.get("https://5-data.amae-koromo.com/api/v2/pl3/search_player/"+urllib.parse.quote(name)+"?limit=20&tag=all", timeout=4)
    data0 = json.loads(r0.text)
  except:
    await ctx.channel.send(embed = ex)
    return

  text = discord.Embed(title = botname)
  text.add_field(name = "資料處理中...", value = " ", inline=False)
  text.set_footer(text = foot)
  msg = await ctx.channel.send(embed = text)
  msg_id = int(msg.id)
  try:  
    await fetch_data(msg_id,data0,name,server,botname,foot,ex)
  except Exception as e:
    print(e)
    text = discord.Embed(title = botname)
    text.add_field(name = "Error: Time out.", value = " ", inline=False)
    text.set_footer(text = foot)
    await msg.edit(embed = text)
    return
  for _ in range(1):
    #await asyncio.sleep(5)
    if(mjsdata.get(msg_id) != None):
      await msg.edit(embed = mjsdata[msg_id])
      mjsdata[msg_id] = None
      return
  await msg.edit(embed = ex)

async def fetch_data(msg_id,data0,name,server,botname,foot,ex):
  print("id", msg_id)
  global mjsdata
  reward = [55,95,70,125,75,135] #shima 1st
  reward2 = [25,45,35,60,35,65] #shima 2nd
  reward3 = [70,120,90,175,135,255] #sanma 1st

  def trans(lv):
    if(lv < 1):
      return "士1-"
    if(lv < 3.995):
      return "士"+str(round(lv,2))
    if(lv < 6.995):
      return "傑"+str(round(lv-3,2))
    if(lv < 9.995):
      return "豪"+str(round(lv-6,2))
    if(lv > 99.99):
      return "inf"
    return "聖"+str(round(lv-9,2))

  def penalty3(x,south):
    if (south == 1):
      if(x < 6):
        return 15 + x*20
      if(x < 7):
        return -135 + x*45
      return 5 + x*25
    else:
      if(x < 6):
        return 15 + x*10
      if(x < 7):
        return -45 + x*20
      return -10 + x*15

  def penalty4(x,south):
    if (south == 1):
      if(x < 6):
        return 15 + x*20
      if(x < 7):
        return -135 + x*45
      return 75 + x*15
    else:
      if(x < 6):
        return 15 + x*10
      if(x < 7):
        return -45 + x*20
      return 25 + x*10

  def stable3(x,rank,small):
    l = 0
    r = 100
    cnt = 0
    while l < r and cnt < 60:
      m = (l+r)/ 2
      if(small + reward3[x]*rank[0] - penalty3(m,x%2)*rank[2] > 0):
        l = m
      else:
        r = m
      cnt += 1
    return trans(l)

  def stable4(x,rank,small):
    l = 0
    r = 100
    cnt = 0
    while l < r and cnt < 60:
      m = (l+r)/ 2
      if(small + reward[x]*rank[0] + reward2[x]*rank[1] - 5*rank[2] - penalty4(m,x%2)*rank[3] > 0):
        l = m
      else:
        r = m
      cnt += 1
    return trans(l)

  def konten_stable4(rank,drank):
    print(drank)
    st = (rank[0]+drank[0]-rank[3]-drank[3])*0.5+(rank[1]+drank[1]-rank[2]-drank[2])*0.2
    st /= sum(rank)
    return round(st,4)

  def tlv(lv):
    lv %= 10000
    if(lv//100 == 7):
      return lv - 690
    return 3 * (lv//100-2) + lv%100 - 2

  mode3 = ["21","22","23","24","25","26"]
  mode4 = ["8","9","11","12","15","16"]
  level = ["None","士3","傑1","傑2","傑3","豪1","豪2","豪3","聖1","聖2","聖3"]
  upgrade = [1000,1000,1200,1400,2000,2800,3200,3600,4000,6000,9000]
  for _ in range(19):
    upgrade.append(2000)
  upgrade.append(1000000000) #inf
  serv = None
  for x in range(len(data0)):
    id = data0[x]['id']
    serv = id / pow(2,23)
    if(serv <= 6): serv = "china"
    elif(serv <= 12): serv = "japan"
    elif(serv <= 15): serv = "inter"

    if(name != data0[x]['nickname'] or (server != "all" and server != serv)):
      continue
    else:
      break 

    # prefix = "https://5-data.amae-koromo.com/api/v2/pl3/player_records/"+str(id)+"/"
    # suffix = "/1262304000000?limit=500&mode=26,24,22,23,21&descending=true&tag="
  t = 3000000000999
  clv = 0
  movement3 = []
  mp3 = {}
  small3 = []
    # rep = False
    # for i in range(len(mode3)):
    #   mp3[mode3[i]] = i
    #   small3.append(0)
    # try:
    #   for _ in range(50):
    #     r = requests.get(prefix+str(t)+suffix, timeout=4)
    #     data = json.loads(r.text)
    #     for i in data:
    #       if(rep):
    #         rep = False #repeat
    #         continue
    #       t = i.get('startTime')
    #       idx = mp3[str(i['modeId'])]
    #       for j in i.get('players'):
    #         lv = j['level']
    #         if(lv == 20601) : lv = 20701
    #         if(j['accountId'] == id):
    #           small3[idx] += int(math.ceil((int(j['score'])-35000)/1000)) 
    #           if(clv != lv):
    #             clv = lv
    #             movement3.append(tlv(clv))
    #     if(len(data) < 500):
    #       break
    #     rep = True
    # except:
    #   pass
    # prefix = "https://5-data.amae-koromo.com/api/v2/pl4/player_records/"+str(id)+"/"
    # suffix = "/1262304000000?limit=500&mode=8,9,11,12,15,16&descending=true&tag="
  t = 3000000000999
  clv = 0
  delta = 0
  movement4 = []
  mp4 = {}
  small4 = []
  rep = False
  konten_rank = [0,0,0,0]
  # for i in range(len(mode4)):
  #   mp4[mode4[i]] = i
  #   small4.append(0)
    # try:
    #   for _ in range(50):
    #     r = requests.get(prefix+str(t)+suffix, timeout=4)
    #     data = json.loads(r.text)
    #     for i in data:
    #       konten = 0
    #       t = i.get('startTime')
    #       idx = mp4[str(i['modeId'])]
    #       for j in i.get('players'):
    #         lv = j['level']
    #         if(lv == 10601) : lv = 10701
    #         if(lv >= 10701) : konten += 1
    #         if(j['accountId'] == id):
    #           small4[idx] += int(math.ceil((int(j['score'])-25000)/1000)) 
    #           delta = int(j["gradingScore"])
    #           if(clv != lv):
    #             clv = lv
    #             movement4.append(tlv(clv))
    #         if(konten == 4 and idx == 5):
    #           if(delta == 100): konten_rank[0] += 1
    #           if(delta == 40): konten_rank[1] += 1
    #           if(delta == -40): konten_rank[2] += 1
    #           if(delta == -100): konten_rank[3] += 1
    #     if(len(data) < 500):
    #       break
    # except:
    #   pass
  re3 = []; re4 = []
  timeout = aiohttp.ClientTimeout(total=300)
  async with aiohttp.ClientSession(timeout = timeout) as session:
    for i in mode3:
      rank = []; data = []
      async with session.get("https://5-data.amae-koromo.com/api/v2/pl3/player_stats/"+str(id)+"/1262304000000/1999999999999?mode="+i+"&tag=", timeout = 10) as r:
        if r.status == 200: 
          data = await r.json()  
        else:
          print("Err Fetch")
          re3.append(rank)
          continue   
      #data = json.loads(r.text)

      for j in range(3):
        rank.append(int(round(float(data['rank_rates'][j])*int(data['count']),0)))
      print("rank3", i)
      re3.append(rank)

    for i in mode4:
      rank = []; data = []
      async with session.get("https://5-data.amae-koromo.com/api/v2/pl4/player_stats/"+str(id)+"/1262304000000/1999999999999?mode="+i+"&tag=", timeout = 10) as r:
        if r.status == 200: 
          data = await r.json()  
        else:
          print("Err Fetch")
          re4.append(rank)
          continue  
      #data = json.loads(r.text)

      for j in range(4):
        rank.append(int(round(float(data['rank_rates'][j])*int(data['count']),0)))
      print("rank4", i)
      re4.append(rank)

    data = []
    lv3 = 0
    pt3 = 0
    try:
      async with session.get("https://5-data.amae-koromo.com/api/v2/pl3/player_stats/"+str(id)+"/1262304000000/1999999999999?mode=21,22,23,24,25,26&tag=", timeout = 10) as r:
        if r.status == 200: 
          data = await r.json()  
        else:
          print("Err Fetch")
          pass  
      print("lv3")
      lv3 = tlv(int(data["level"]['id']))
      pt3 = int(data["level"]['score']) + int(data["level"]['delta'])
      if(pt3 < 0):
        lv3 -= 1
        pt3 = upgrade[lv3]//2
        movement3.insert(0,lv3)
      if(pt3 >= upgrade[lv3]):
        lv3 += 1
        pt3 = upgrade[lv3]//2
        movement3.insert(0,lv3)
    except:
      print("lv3 err")
      pass
    data = []
    lv4 = 0
    pt4 = 0
    try:
      async with session.get("https://5-data.amae-koromo.com/api/v2/pl4/player_stats/"+str(id)+"/1262304000000/3000000000999?mode=8,9,11,12,15,16&tag=", timeout = 10) as r:
        if r.status == 200: 
          data = await r.json()  
        else:
          print("Err Fetch")
          pass  
      print("lv4")
      lv4 = tlv(int(data["level"]['id']))
      pt4 = int(data["level"]['score']) + int(data["level"]['delta'])
      if(pt4 < 0):
        lv4 -= 1
        pt4 = upgrade[lv4]//2
        movement4.insert(0,lv4)
      if(pt4 >= upgrade[lv4]):
        lv4 += 1
        pt4 = upgrade[lv4]//2
        movement4.insert(0,lv4)
    except:
      print("lv4 err")
      pass
  print("done", lv3, lv4)
  wlv3 = "無資料"
  wlv4 = "無資料"
  if(lv3 > 10):
    pt3 /= 100
    wlv3 = "魂"+str(lv3-10)
  elif(lv3 > 0):
    wlv3 = level[lv3]
  if(lv4 > 10):
    pt4 /= 100
    wlv4 = "魂"+str(lv4-10)
  elif(lv4 > 0):
    wlv4 = level[lv4]

  for i in range(len(movement3)):
    if(movement3[i] > 10):
      movement3[i] = "魂"+str(movement3[i]-10)
    else:
      movement3[i] = level[movement3[i]]

  for i in range(len(movement4)):
    if(movement4[i] > 10):
      movement4[i] = "魂"+str(movement4[i]-10)
    else:
      movement4[i] = level[movement4[i]]
  serv_tag = ""
  if(serv == "china"): serv_tag = "(C)"
  if(serv == "japan"): serv_tag = "(J)"
  if(serv == "inter"): serv_tag = "(I)"
  text = discord.Embed(title = botname)
  text.add_field(name = name + serv_tag, value = " ", inline=False)
  text.set_footer(text = foot)
  table = ["金東","金南","玉東","玉南","王座東","王座南"]
  if(wlv3 == "無資料"):
    text.add_field(name = "三麻", value = "無資料", inline=False)
  else:
    s = "段位推移: "
    for k in movement3:
      s += k + " "
    s += "\n\n"
    su = ["-","-"," "]
    for k in range(len(re3)):
      if(len(re3[k]) == 0): continue
      s += table[k] + " : "
      for p in range(3):
        s += str(re3[k][p]) + su[p]
      s += "(安 " + str(stable3(k,re3[k],0))  #small3[k]/1
      if(sum(re3[k]) < 500): s += "?"
      s += ")\n"
    grade3 = "三麻 " + wlv3 + " " + str(pt3) 
    if(lv3 <= 10):
      grade3 += "/" + str(upgrade[lv3])
    elif(lv3 < 30):
      grade3 += "/20.0"  
    grade3 += " pt"
    text.add_field(name = grade3, value = s, inline=False)

  if(wlv4 == "無資料"):
    text.add_field(name = "四麻", value = "無資料", inline=False)
  else:
    s = "段位推移: "
    for k in movement4:
      s += k + " "
    s += "\n\n"
    su = ["-","-","-"," "]
    for k in range(len(re4)):
      if(len(re4[k]) == 0): continue
      s += table[k] + " : "
      for p in range(4):
        s += str(re4[k][p]) + su[p]
      s += "(安 " + str(stable4(k,re4[k],0)) #small4[k]/1
      if(k == 5 and lv4 > 10):
        s += ", 魂"
        k_st = konten_stable4(re4[5], konten_rank)
        if(k_st >= 0): s += "+"
        s += str(k_st)
      if(sum(re4[k]) < 500): s += "?"
      s += ")\n"
    grade4 = "四麻 " + wlv4 + " " + str(pt4) 
    if(lv4 <= 10):
      grade4 += "/" + str(upgrade[lv4])
    elif(lv4 < 30):
      grade4 += "/20.0"
    grade4 += " pt"
    text.add_field(name = grade4 , value = s,  inline=False)
  print("mjdone")
  mjsdata[msg_id] = text

  return #await msg.edit(embed = ex)