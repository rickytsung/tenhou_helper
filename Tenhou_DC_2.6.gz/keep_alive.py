from flask import Flask
from threading import Thread

app = Flask('')

    
@app.route('/')
def home():
    return "Gomi Game || Made by rickytsung. || Ver: 1.8"

def run():
  app.run(host='0.0.0.0',port=5353)

def keep_alive():
    t = Thread(target=run)
    t.start()